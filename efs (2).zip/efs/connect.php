<?php

	$con = mysqli_connect('localhost','root','','efs');
	
			if($link === false) 
	{
		die('Error connecting to the database ' . mysqli_connect_error());	
	}
?>