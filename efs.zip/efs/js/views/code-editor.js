var editor = CodeMirror.fromTextArea(codemirror, {
  lineNumbers: true,
  mode : "xml",
  htmlMode: true
});
editor.setSize("100%",700);
